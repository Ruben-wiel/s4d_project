# BESTAND VOOR HET WACHTWOORD VARIABELE AANMAKEN
import os

EMAIL_USER = 'djangos4d@gmail.com'
EMAIL_PASS = 'S4dproject'

print(EMAIL_USER)
print(EMAIL_PASS)
