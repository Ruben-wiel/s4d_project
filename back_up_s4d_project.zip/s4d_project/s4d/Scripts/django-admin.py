#!c:\users\jente\documents\git\s4d_project\s4d\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
